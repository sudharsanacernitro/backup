#!/home/sudharsan/myenv/bin/python3
import tkinter as tk
from tkinter import messagebox
import os
class LoginApp:
    def __init__(self, root):
        root.geometry("400x300")
        self.root = root
        self.root.title("Login Page")

        self.login_frame = tk.Frame(root)
        self.login_frame.pack()
        self.next_frame = tk.Frame(root)
        self.username_label = tk.Label(self.login_frame, text="Username:")
        self.username_entry = tk.Entry(self.login_frame)
        self.password_label = tk.Label(self.login_frame, text="Password:")
        self.password_entry = tk.Entry(self.login_frame, show="*")  # Hide password characters
        self.login_button = tk.Button(self.login_frame, text="Login", command=self.validate_login)

        self.username_label.pack()
        self.username_entry.pack()
        self.password_label.pack()
        self.password_entry.pack()
        self.login_button.pack()

    def validate_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if username == "admin" and password == "password":
            self.login_frame.pack_forget()  # Hide login frame
            self.show_next_page()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    def show_next_page(self):
        next_label = tk.Label(self.next_frame, text="Welcome  admin!")
        self.next_frame.pack()
        self.way_label = tk.Label(self.next_frame, text="number of way:") 
        self.way_entry = tk.Entry(self.next_frame)
        self.start_button = tk.Button(self.next_frame, text="start",command=self.start)
        self.stop_button = tk.Button(self.next_frame, text="stop",command=self.stop_window)
        next_label.pack()
        self.way_label.pack()
        self.way_entry.pack()
        self.start_button.pack()
        self.stop_button.pack()
    def start(self):
        way = self.way_entry.get()   
        if(way=='1'):
            os.system("gnome-terminal  -- bash -c ' python3 /home/sudharsan/projects/gui-webchat/ex.py; exec bash'")
            #os.system('firefox http://localhost:81/public/index.ejs')
    def stop_window(self):
        root.destroy()
        os.system('pkill -f gnome-terminal')
        

if __name__ == '__main__':
    root = tk.Tk()
    app = LoginApp(root)
    root.mainloop()

