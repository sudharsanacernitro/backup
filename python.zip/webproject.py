#!/home/sudharsan/myenv/bin/python3
from scapy.all import *

def trace_route(destination_address, max_hops=30):
    count=0
    for ttl in range(1, max_hops + 1):
        # Create an ICMP echo request packet with the specified TTL
        packet = IP(dst=destination_address, ttl=ttl) / ICMP()

        # Send the packet and receive the response
        reply = sr1(packet, verbose=0, timeout=1)

        if reply is None:
            # Timeout, print an asterisk (*) for unreachable hop
            pass
        else:
            # Print the IP address of the responding host
            a=reply.src[0:9]
            print(reply.src)
            if(a=="61.95.209"):
                print(f"{destination_address} uses amazomaws")

            # Check if the destination is reached
            if reply.src == destination_address:
                count=count+1
                if(count==2):
                    break

# Replace "example.com" with the desired destination address
trace_route("google.com")
#116.119.61.204   61.95.209.57
