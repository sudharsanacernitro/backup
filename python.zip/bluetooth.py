#import netfilterqueue
import scapy.all as scapy

def process_packet(packet):
    scapy_packet = scapy.IP(packet.get_payload())
    if scapy_packet.haslayer(scapy.Raw):
        load = scapy_packet[scapy.Raw].load
        if b"example.com" in load:
            print("[+] Blocking request to example.com")
            packet.drop()
        elif b"jpg" in load:
            print("[+] Blocking JPG request")
            packet.drop()
    packet.accept()

process_packet()
