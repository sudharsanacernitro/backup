#!/home/sudharsan/myenv/bin/python3
import os
#os.system('./vpn.py')
os.system('echo Tatakae-nitro | sudo -S ./vpn.py')
