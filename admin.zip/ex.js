const nodemailer = require('nodemailer');

// Create a transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'sudharsanr.22cse@kongu.edu',
    pass: 'ram123$$$',
  },
});

// Setup email data
const mailOptions = {
  from: 'sudharsanr.22cse@kongu.edu',
  to: 'sudharsanr.22cse@kongu.edu',
  subject: 'Hello from Node.js',
  text: 'This is a test email sent from Node.js.',
};

// Send the email
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    return console.error('Error:', error);
  }
  console.log('Email sent:', info.response);
});

