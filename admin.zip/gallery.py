import sqlite3
import sys

l = sys.argv[1:]
print(l[1])
db_file_path = 'database.db'

# Connect to the SQLite database
conn = sqlite3.connect(db_file_path)
cursor = conn.cursor()

def check():
    table_name = l[0]
    query = f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'"
    cursor.execute(query)
    result = cursor.fetchone()

    return result is not None

if check():
    insert_query = f'''
        INSERT INTO {l[0]} (field_name)
        VALUES (?)
    '''
    cursor.execute(insert_query, (l[1],))
    print("Data inserted successfully")
else:
    table_creation_query = f'''
        CREATE TABLE IF NOT EXISTS {l[0]} (
            field_name TEXT
        )
    '''
    cursor.execute(table_creation_query)

    insert_query = f'''
        INSERT INTO {l[0]} (field_name)
        VALUES (?)
    '''
    cursor.execute(insert_query, (l[1],))
    print("Table and data inserted successfully")

# Commit the changes and close the connection
conn.commit()
cursor.close()
conn.close()

