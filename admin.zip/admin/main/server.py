import sqlite3

# Connect to SQLite database
conn = sqlite3.connect('/home/sudharsan/projects/demo-projects/your_database.db')

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Insert values into the 'person' table
insert_query = '''
    SELECT email FROM key_pair WHERE key='abcd';
'''

# Data to be inserted
data_to_insert = [
    ("abcd", "sudharsanr.22cse@kongu.edu"),
    ("jikl","sudharsanr836@gmail.com"),
    ("xyzk", "iamsudharsanr@gmail.com"),
    ("abce", "shyamsaranr.22cse@kongu.edu"),
    ("jiko","siva.22cse@kongu.edu"),
    ("xyzp", "sakthi.22cse@kongu.edu")
    
]

# Execute the insert query for each set of data
cursor.execute(insert_query)
result=cursor.fetchall()
print(result[0][0])

# Commit the changes and close the connection
conn.commit()
conn.close()

