import csv
import sqlite3
import os
import shutil
import json
conn = sqlite3.connect('/home/sudharsan/projects/demo-projects/your_database.db')
cursor=conn.cursor()
csv_file_path = 'main.csv'
output_csv_path = 'duplicate.csv'
def data():
    a=[]
    with open(csv_file_path, 'r') as file:
        csv_reader = csv.DictReader(file)
        header = csv_reader.fieldnames

        for row in csv_reader:
            print(row['key'], row['path'], row['quantity'])
            for i in ['key','path','quantity']:
                a.append(row[i])
            print('\n')
            with open(output_csv_path, 'a', newline='') as output_file:
                writer = csv.DictWriter(output_file, fieldnames=header)
                if output_file.tell() == 0:
                    writer.writeheader()
                writer.writerow(row)
    with open(csv_file_path, 'w', newline='') as input_file:
        writer = csv.DictWriter(input_file, fieldnames=header)
        writer.writeheader()
    return a
    
def call(var):
    insert_query = f'''
    SELECT email FROM key_pair WHERE key='{var}';
    '''
    cursor.execute(insert_query)
    result=cursor.fetchall()
    folder=result[0][0]
    return folder
    conn.commit()
    conn.close()
def folder(var):
    l2=os.listdir('/home/sudharsan/projects/demo-projects/pic')
    if var in l2:
        return True
    else:
        return False
def create(var):
    os.makedirs('/home/sudharsan/projects/demo-projects/pic/'+var, exist_ok=True)
def checkdir(var):
    l=os.listdir('/home/sudharsan/projects/demo-projects/pic/'+var)
    count=0
    for i in l:
        if '.png' in i:
            count=count+1
    return (count)
def changeimg(var1,var2):
   count= checkdir(var2)
   old_filepath = var1
   new_filepath = f'/home/sudharsan/projects/demo-projects/pic/{var2}/{count+1}.png'
   shutil.move(old_filepath, new_filepath)
   return count
def create_json(var1,var2,var):
    img_name=f'{var1+1}.png'
    data_to_write = {
        img_name:var2
     }
    json_filename = f'/home/sudharsan/projects/demo-projects/pic/{var}/quantity.json'
    if os.path.exists(json_filename):
        with open(json_filename, 'r') as file:
            existing_data = json.load(file)
        existing_data.update(data_to_write)
        with open(json_filename, 'w') as file:
            json.dump(existing_data, file, indent=2)
        print("Json file already exsists and contents are updated")
    else:
        with open(json_filename, 'w') as file:
            json.dump(data_to_write, file, indent=2)
        print("Json file is created and updated")

    
l1=data()
var=call(l1[0])
key=folder(var)
if not key:
    create(var)
count=changeimg(l1[1],var)
create_json(count,l1[2],var)
