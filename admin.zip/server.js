const { spawn } = require('child_process');

const pythonScript = 'gallery.py';
const pythonProcess = spawn('python3', [pythonScript,'ex1','hai']);

pythonProcess.stdout.on('data', (data) => {
  console.log(`Python stdout: ${data}`);
});

pythonProcess.stderr.on('data', (data) => {
  console.error(`Python stderr: ${data}`);
});

pythonProcess.on('close', (code) => {
  console.log(`Python process exited with code ${code}`);
});

