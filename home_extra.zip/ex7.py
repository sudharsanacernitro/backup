#!/home/sudharsan/myenv/bin/python3
import socket

def get_main_phone_ip():
    # Create a socket to get the local IP address
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:
        # Connect to an external server (doesn't have to be reachable)
        s.connect(('8.8.8.8', 80))

        # Get the local IP address
        local_ip = s.getsockname()[0]
        print(f"Main Phone IP Address: {local_ip}")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        # Close the socket
        s.close()

# Get the main phone's IP address
get_main_phone_ip()

