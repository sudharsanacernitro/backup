#!/home/sudharsan/myenv/bin/python3
from pymongo import MongoClient 

# Replace the following connection string with your MongoDB connection string


# Create a MongoClient object
client = MongoClient("localhost",27017)

# Access a specific database (replace 'your_database' with your actual database name)
db = client.test1

# Access a specific collection within the database (replace 'your_collection' with your actual collection name)
collection = db.mycollection

# Example: Insert a document into the collection
#document_to_insert = {"name": "John", "age": 30, "city": "New York"}
#collection.insert_one(document_to_insert)

# Example: Query all documents in the collection
documents = collection.find()
for document in documents:
    print(document)

# Close the connection
client.close()
