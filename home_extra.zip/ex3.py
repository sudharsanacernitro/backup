#!/home/sudharsan/myenv/bin/python3
import nmap

def nmap_recursive_scan(main_subnet):
    # Create an instance of the NmapPortScanner class
    nm = nmap.PortScanner()

    # Perform an initial scan to identify hosts in the main subnet
    nm.scan(hosts=main_subnet, arguments='-sn')

    # Iterate through the discovered hosts
    for host in nm.all_hosts():
        print(f"Scanning subnets for host: {host}")

        # Perform a more detailed scan to identify subnets within the main subnet
        nm.scan(hosts=f"{host}/24", arguments='-sn')

        # Iterate through the discovered subnets
        for subnet_host in nm.all_hosts():
            print(f"  Scanning subnet: {subnet_host}")
            nmap_scan_subnet(subnet_host)

def nmap_scan_subnet(subnet):
    # Perform a basic TCP scan on all hosts in the specified subnet
    nm = nmap.PortScanner()
    nm.scan(hosts=subnet, arguments='-p 1-1000')

    # Print scan results
    for host in nm.all_hosts():
        print(f"  Host: {host}")
        for proto in nm[host].all_protocols():
            print(f"    Protocol: {proto}")
            ports = nm[host][proto].keys()
            for port in ports:
                state = nm[host][proto][port]['state']
                print(f"      Port: {port}\tState: {state}")

if __name__ == "__main__":
    # Specify the main subnet to start the recursive scan
    main_subnet = "10.1.32.0/24"

    # Perform the recursive scan starting from the main subnet
    nmap_recursive_scan(main_subnet)

