#!/home/sudharsan/myenv/bin/python3
#!/home/sudharsan/myenv/bin/python3
from scapy.all import IP, TCP, DNS
from scapy.all import sniff
from subprocess import Popen, PIPE

def block_http(packet):
    if IP in packet and TCP in packet:
        ip_src = packet[IP].src
        ip_dst = packet[IP].dst
        tcp_sport = packet[TCP].sport
        tcp_dport = packet[TCP].dport

        print(f"Source IP: {ip_src}, Destination IP: {ip_dst}, Source Port: {tcp_sport}, Destination Port: {tcp_dport}")

    if DNS in packet:
        print(f"DNS Query: {packet[DNS].qd.qname.decode('utf-8').lower()}")

# Set the filter to capture all packets
sniff_filter = ''

# Apply iptables rule to drop UDP packets on port 53
Popen(["iptables -A INPUT -p udp --dport 53 -j DROP"], shell=True, stdout=PIPE)
Popen(["iptables -A OUTPUT -p udp --sport 53 -j DROP"], shell=True, stdout=PIPE)

# Sniff all packets and apply the block_http function to each packet
while True:
    sniff(prn=block_http, filter=sniff_filter, store=0)

