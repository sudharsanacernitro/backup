#!/home/sudharsan/myenv/bin/python3
import requests
from bs4 import BeautifulSoup
l1=[]
def get_all_anchors(url):

    response = requests.get(url)


    if response.status_code == 200:

        soup = BeautifulSoup(response.text, 'html.parser')


        anchor_tags = soup.find_all('a')


        for anchor_tag in anchor_tags:
            #print(anchor_tag.get('href'))
            l1.append(anchor_tag.get('href'))
            

    


url_to_scrape = 'https://www.kongu.ac.in/'
url=url_to_scrape
get_all_anchors(url_to_scrape)
#print(l1)
for i in range(len(l1)):
    a=l1[i].split('/')
    if a[0]=="https:" or a[0]=="http:":
        print(l1[i])
        try:
            response = requests.get(l1[i],timeout=10)

        except Exception:
            pass
        if response.status_code == 200:

            soup = BeautifulSoup(response.text, 'html.parser')
            anchor_tags = soup.find_all('a')
            for anchor_tag in anchor_tags:
                href=anchor_tag.get('href')
                if href:
                    if href!='#':
                        if 'http' not in href:
                            l1.append(l1[i]+'/'+anchor_tag.get('href'))
                        else:
                            l1.append(href)
    else:
        print(url+l1[i])
        try:
            response = requests.get(url+l1[i], timeout=10)
        except Exception:
            pass
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            anchor_tags = soup.find_all('a')
            for anchor_tag in anchor_tags:
                href=anchor_tag.get('href')
                if href:
                    if href!='#':
                        if 'http' not in href:
                            l1.append(url+l1[i]+'/'+anchor_tag.get('href'))
                        else:
                            l1.append(href)
print(l1) 
