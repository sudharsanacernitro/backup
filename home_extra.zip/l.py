#!/home/sudharsan/myenv/bin/python3
def split_file(input_file, output_directory, chunk_size=80*1024 * 1024):
    # Open the large file for reading in binary mode
    with open(input_file, 'rb') as file:
        # Read the content of the large file in chunks
        chunk_number = 1
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                break  # Break the loop if no more data

            # Create a new binary file for each chunk
            output_file = f"{output_directory}/chunk_{chunk_number}.bin"
            with open(output_file, 'wb') as output:
                output.write(chunk)

            print(f"Chunk {chunk_number} written to {output_file}")
            chunk_number += 1

# Example usage:
input_large_file = 'Downloads/king-kotha.mp4'
output_directory = 'Videos'

# Create the output directory if it doesn't exist
import os
os.makedirs(output_directory, exist_ok=True)

split_file(input_large_file, output_directory)

