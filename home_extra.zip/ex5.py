#!/home/sudharsan/myenv/bin/python3
import requests
from bs4 import BeautifulSoup


class_to_find = "col-xl-3"
url = "https://www.bitsathy.ac.in/departments/faculty/#aeronautical-engineering"
# Send a GET request to the URL
response = requests.get(url)
l=[]
# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all div tags with the specific class name
    divs_with_class = soup.find_all('div', class_=class_to_find)

    # Print or use the results as needed
    for div in divs_with_class:
        if div:
        # Find all anchor tags inside the div
            anchor_tags = div.find_all('a')

        # Print or use the results as needed
            for anchor_tag in anchor_tags:
                k=anchor_tag.get('href').split("#")
                if "aeronautical-engineering"==k[1]:
                    l.append(anchor_tag.get("href"))
print(l)
j=0
count=0
m1=[]
m2=[]
for i in l:
    j=j+1
    m1.append((i.split('/')[5]))
    response=requests.get(i)
    if response.status_code == 200:
    # Parse the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')

    # Find all div tags with the specific class name
        divs = soup.find_all('div', class_="Journal-Publications")
        #print(divs)
        if divs:
            anchor_tags = divs[0].find_all('li')
            for anchor_tag in anchor_tags:
                #print(anchor_tag.text)
                count=count+1
            m2.append(count)
            count=0
maxi=0
for i in range(len(m1)):
    print(m1[i]+":"+str(m2[i]))
    if maxi<m2[i]:
        maxi=m2[i]
print("\n persons with highest journal published\n")
for i in range(len(m1)):
    if maxi==m2[i]:
        print(m1[i]+":"+str(m2[i]))    
