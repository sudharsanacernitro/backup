import subprocess
subprocess.run(["sudo","ifconfig","wlp0s20f3","down"])
subprocess.run(["sudo","macchanger","-m","0c:9a:3c:4e:e2:3d","wlp0s20f3"])
subprocess.run(["sudo","ifconfig","wlp0s20f3","up"])

