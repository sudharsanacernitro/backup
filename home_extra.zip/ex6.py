#!/home/sudharsan/myenv/bin/python3
import json
import openai
openai.api_key="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"


# Define a prompt
prompt = "give me ceo ,director,HR,networth,aim of spacex in the format CEO:value,DIRECTOR:value,HR:value,NETWORTH:value,AIM:value"
prompt=prompt.replace('–','')
# Make a request to the ChatGPT model
response = openai.Completion.create(
    engine="text-davinci-003",  # You can use different engines, choose the one that fits your needs
    prompt=prompt,
    max_tokens=150  # You can adjust this parameter based on your desired response length
)

# Extract the generated response
string =""
e=[]
chatgpt_response = response['choices'][0]['text']
json_list = json.dumps(chatgpt_response.split("\n"))
print(json_list)

# Print the response
#print(chatgpt_re)
#give me the product key values like product name,price,specification,shipping,offer,discount,stock charges from this paragraph" prompt = "..........give me the product's model name,product price from this paragraph in this format product-name:value,price:value"
