import java.util.*;
import java.lang.Thread;
class add extends java.lang.Thread
{
int a,b;
add(int a,int b)
{
this.a=a;
this.b=b;
}
public void run()
{
Add();
}
void Add()
{
System.out.println("add:"+a+b);
}
}


class sub extends java.lang.Thread
{
int a,b;
sub(int a,int b)
{
this.a=a;
this.b=b;
}
public void run()
{
Sub();
}
void Sub()
{
System.out.println("Subtract:"+(a-b));
}
}


class mul extends java.lang.Thread
{
int a,b;
mul(int a,int b)
{
this.a=a;
this.b=b;
}
public void run()
{
Sub();
}
void Sub()
{
System.out.println("Multiplication:"+(a*b));
}
}


class div extends java.lang.Thread
{
int a,b;
div(int a,int b)
{
this.a=a;
this.b=b;
}
public void run()
{
Div();
}
void Div()
{
 try {
            // Sleep for 3 seconds (3000 milliseconds)
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            // Handle the InterruptedException if necessary
            e.printStackTrace();
        }
System.out.println("Division:"+(a/b));
}
}




class Main 
{
 public static void main (String[] args) {

        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        add a1=new add(a,b);
        sub s1=new sub(a,b);
        mul m1=new mul(a,b);
        div d1=new div(a,b);
        d1.start();
        s1.start();
        a1.start();
        m1.start();

}

}
